from setuptools import setup

setup(
    name='m3_project',
    version='1.0.0',
    packages=['migrations'],
    # package_dir={'': 'm3_project/app'},
    url='localhost',
    license='',
    author='vladick',
    author_email='',
    description='v1'
)
